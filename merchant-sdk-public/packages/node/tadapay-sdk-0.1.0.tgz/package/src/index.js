import crypto from "node:crypto";

export const AVALANCHE_X402_ASSETS = Object.freeze({
  mainnet: Object.freeze({
    XSGD: Object.freeze({
      symbol: "XSGD",
      address: "0xb2F85b7AB3c2b6f62DF06dE6aE7D09c010a5096E",
      name: "XSGD",
      version: "2",
      decimals: 6,
      network: "eip155:43114",
    }),
    USDC: Object.freeze({
      symbol: "USDC",
      address: "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E",
      name: "USD Coin",
      version: "2",
      decimals: 6,
      network: "eip155:43114",
    }),
  }),
  fuji: Object.freeze({
    XSGD: Object.freeze({
      symbol: "XSGD",
      address: "0xd769410dc8772695a7f55a304d2125320a65c2a5",
      name: "XSGD",
      version: "2",
      decimals: 6,
      network: "eip155:43113",
    }),
    USDC: Object.freeze({
      symbol: "USDC",
      address: "0x5425890298aed601595a70AB815c96711a31Bc65",
      name: "USD Coin",
      version: "2",
      decimals: 6,
      network: "eip155:43113",
    }),
  }),
});

export const X402_FACILITATORS = Object.freeze({
  ZEROXGASLESS: Object.freeze({
    profile: "0xgasless",
    url: "https://x402.0xgasless.com",
  }),
});

/**
 * Build a merchant-direct x402 option for Avalanche.
 * The merchant's wallet is always the pay_to recipient; TadaPay never
 * becomes the funds recipient by using this helper.
 */
export function createAvalancheX402PaymentOption({
  payTo,
  price,
  asset = "XSGD",
  network = "mainnet",
  scheme = "exact",
  facilitatorProfile = "0xgasless",
  facilitatorUrl,
  description,
  mimeType,
} = {}) {
  if (!payTo || !/^0x[a-fA-F0-9]{40}$/.test(String(payTo))) {
    throw new Error("payTo must be a valid EVM merchant wallet address");
  }
  const networkKey = network === "eip155:43114" ? "mainnet" : network === "eip155:43113" ? "fuji" : network;
  const assets = AVALANCHE_X402_ASSETS[networkKey];
  if (!assets) throw new Error("network must be mainnet, fuji, eip155:43114, or eip155:43113");
  const assetKey = String(asset).toUpperCase();
  const assetConfig = assets[assetKey] || Object.values(assets).find(
    (candidate) => candidate.address.toLowerCase() === String(asset).toLowerCase(),
  );
  if (!assetConfig) throw new Error(`unsupported Avalanche asset: ${asset}`);
  if (scheme !== "exact") throw new Error("Avalanche x402 options currently support only exact scheme");

  const option = {
    rail: "x402",
    scheme,
    network: assetConfig.network,
    asset: assetConfig.address,
    pay_to: String(payTo),
    decimals: assetConfig.decimals,
    facilitator_profile: facilitatorProfile,
    extra: { name: assetConfig.name, version: assetConfig.version },
  };
  if (price !== undefined && price !== null) option.price = String(price);
  if (facilitatorUrl) option.facilitator_url = String(facilitatorUrl);
  if (description) option.description = String(description);
  if (mimeType) option.mime_type = String(mimeType);
  return option;
}

export class TadaPayAPIError extends Error {
  constructor({ message, status, error, detail, body }) {
    super(message);
    this.name = "TadaPayAPIError";
    this.status = status;
    this.error = error;
    this.detail = detail;
    this.body = body;
  }
}

export class TadaPayClient {
  constructor({ apiKey, baseUrl = "http://127.0.0.1:8080", timeoutMs = 30000 }) {
    if (!apiKey) throw new Error("apiKey is required");
    this.apiKey = apiKey;
    this.baseUrl = baseUrl.replace(/\/$/, "");
    this.timeoutMs = timeoutMs;
  }

  async createAgentPaymentIntent(payload, options = {}) {
    return this.request("POST", "/v1/agent_payment_intents", payload, options);
  }

  async getAgentPaymentIntent(intentId) {
    return this.request("GET", `/v1/agent_payment_intents/${intentId}`);
  }

  async listAgentPaymentIntents(params = {}) {
    return this.request("GET", withQuery("/v1/agent_payment_intents", params));
  }

  async cancelAgentPaymentIntent(intentId) {
    return this.request("POST", `/v1/agent_payment_intents/${intentId}/cancel`);
  }

  async getAgentPaymentIntentTimeline(intentId) {
    return this.request("GET", `/v1/agent_payment_intents/${intentId}/timeline`);
  }

  async createCheckoutSession(payload, options = {}) {
    return this.request("POST", "/v1/checkout_sessions", payload, options);
  }

  async getCheckoutSession(sessionId) {
    return this.request("GET", `/v1/checkout_sessions/${sessionId}`);
  }

  async expireCheckoutSession(sessionId) {
    return this.request("POST", `/v1/checkout_sessions/${sessionId}/expire`);
  }

  async getHostedCheckoutSessionStatus(sessionId) {
    return this.request("GET", `/checkout/sessions/${sessionId}/status`);
  }

  async createAgentCheckout(intentPayload, options = {}) {
    const intent = await this.createAgentPaymentIntent(intentPayload, {
      idempotencyKey: options.idempotencyKey,
      timeoutMs: options.timeoutMs,
    });
    const sessionPayload = {
      intent_id: intent.id,
      ...(options.checkoutSession || {}),
    };
    const checkoutSession = await this.createCheckoutSession(sessionPayload, {
      idempotencyKey: options.sessionIdempotencyKey,
      timeoutMs: options.timeoutMs,
    });
    return { intent, checkoutSession, hostedUrl: checkoutSession.hosted_url };
  }

  async listReceipts(params = {}) {
    return this.request("GET", withQuery("/v1/receipts", params));
  }

  async getReceipt(receiptId) {
    return this.request("GET", `/v1/receipts/${receiptId}`);
  }

  async createRefund(payload, options = {}) {
    return this.request("POST", "/v1/refunds", payload, options);
  }

  async listRefunds(params = {}) {
    return this.request("GET", withQuery("/v1/refunds", params));
  }

  async getRefund(refundId) {
    return this.request("GET", `/v1/refunds/${refundId}`);
  }

  async createWebhookEndpoint(payload, options = {}) {
    return this.request("POST", "/v1/webhook_endpoints", payload, options);
  }

  async listWebhookEndpoints(params = {}) {
    return this.request("GET", withQuery("/v1/webhook_endpoints", params));
  }

  async rotateWebhookSecret(endpointId) {
    return this.request("POST", `/v1/webhook_endpoints/${endpointId}/rotate_secret`);
  }

  async testWebhookEndpoint(endpointId) {
    return this.request("POST", `/v1/webhook_endpoints/${endpointId}/test`);
  }

  async listWebhookDeliveries(params = {}) {
    return this.request("GET", withQuery("/v1/webhook_deliveries", params));
  }

  async retryWebhookDelivery(deliveryId) {
    return this.request("POST", `/v1/webhook_deliveries/${deliveryId}/retry`);
  }

  async listRailTransactions(params = {}) {
    return this.request("GET", withQuery("/v1/rail_transactions", params));
  }

  async getRailTransaction(transactionId) {
    return this.request("GET", `/v1/rail_transactions/${transactionId}`);
  }

  async listEvents(params = {}) {
    return this.request("GET", withQuery("/v1/events", params));
  }

  async getAdapterStatus() {
    return this.request("GET", "/v1/adapter_status");
  }

  async createCatalogProduct(payload, options = {}) {
    return this.request("POST", "/v1/catalog/products", payload, options);
  }

  async createCatalogVariant(payload, options = {}) {
    return this.request("POST", "/v1/catalog/variants", payload, options);
  }

  async createCatalogPrice(payload, options = {}) {
    return this.request("POST", "/v1/catalog/prices", payload, options);
  }

  async getCatalogPrice(priceId) {
    return this.request("GET", `/v1/catalog/prices/${priceId}`);
  }

  async upsertCatalogProduct(externalProductId, payload, options = {}) {
    return this.request(
      "PUT",
      `/v1/catalog/products/${encodeURIComponent(externalProductId)}`,
      payload,
      options,
    );
  }

  async listCatalogProducts(params = {}, options = {}) {
    return this.request("GET", withQuery("/v1/catalog/products", params), undefined, options);
  }

  async getCatalogProduct(productId, options = {}) {
    return this.request("GET", `/v1/catalog/products/${productId}`, undefined, options);
  }

  async updateCatalogProduct(productId, payload, options = {}) {
    return this.request("PATCH", `/v1/catalog/products/${productId}`, payload, options);
  }

  async activateCatalogProduct(productId, expectedVersion, options = {}) {
    return this.catalogProductAction(productId, "activate", { expected_version: expectedVersion }, options);
  }

  async publishCatalogProduct(productId, expectedVersion, visibility, options = {}) {
    return this.catalogProductAction(
      productId,
      "publish",
      { expected_version: expectedVersion, visibility },
      options,
    );
  }

  async unpublishCatalogProduct(productId, expectedVersion, options = {}) {
    return this.catalogProductAction(productId, "unpublish", { expected_version: expectedVersion }, options);
  }

  async archiveCatalogProduct(productId, expectedVersion, options = {}) {
    return this.catalogProductAction(productId, "archive", { expected_version: expectedVersion }, options);
  }

  async catalogProductAction(productId, action, payload, options = {}) {
    return this.request("POST", `/v1/catalog/products/${productId}/${action}`, payload, options);
  }

  async replaceCatalogPrice(priceId, payload, options = {}) {
    return this.request("POST", `/v1/catalog/prices/${priceId}/replace`, payload, options);
  }

  async createCatalogCheckout(payload, options = {}) {
    return this.request("POST", "/v1/catalog/checkouts", payload, options);
  }

  /**
   * Discover products published to the cross-merchant agent marketplace.
   * This endpoint is public; the API key is retained for client consistency
   * and is ignored by the gateway for this request.
   */
  async listMarketplaceProducts(params = {}, options = {}) {
    return this.request(
      "GET",
      withQuery("/agent/marketplace/products", params),
      undefined,
      options,
    );
  }

  async getMarketplaceProduct(merchantId, productSlug, options = {}) {
    return this.request(
      "GET",
      `/agent/marketplace/products/${encodeURIComponent(merchantId)}/${encodeURIComponent(productSlug)}`,
      undefined,
      options,
    );
  }

  async createMarketplaceCheckout(payload, options = {}) {
    return this.request("POST", "/agent/marketplace/checkouts", payload, options);
  }

  async createPayer(payload, options = {}) {
    return this.request("POST", "/v1/payers", payload, options);
  }

  async getPayer(payerId) {
    return this.request("GET", `/v1/payers/${payerId}`);
  }

  async listPayers(params = {}) {
    return this.request("GET", withQuery("/v1/payers", params));
  }

  async createSubscription(payload, options = {}) {
    return this.request("POST", "/v1/subscriptions", payload, options);
  }

  async getSubscription(subscriptionId) {
    return this.request("GET", `/v1/subscriptions/${subscriptionId}`);
  }

  async listSubscriptions() {
    return this.request("GET", "/v1/subscriptions");
  }

  async cancelSubscription(subscriptionId, { mode = "at_period_end", ...options } = {}) {
    return this.request(
      "POST",
      `/v1/subscriptions/${subscriptionId}/cancel`,
      { mode },
      options,
    );
  }

  async reauthorizeSubscription(subscriptionId, options = {}) {
    return this.request(
      "POST",
      `/v1/subscriptions/${subscriptionId}/reauthorize`,
      {},
      options,
    );
  }

  async listInvoices() {
    return this.request("GET", "/v1/invoices");
  }

  async getInvoice(invoiceId) {
    return this.request("GET", `/v1/invoices/${invoiceId}`);
  }

  async retryInvoice(invoiceId, options = {}) {
    return this.request("POST", `/v1/invoices/${invoiceId}/retry`, {}, options);
  }

  async getPaymentMandate(mandateId) {
    return this.request("GET", `/v1/payment_mandates/${mandateId}`);
  }

  async confirmAgentPaymentRequest(requestId, payload = {}, options = {}) {
    return this.request("POST", `/agent/payment_requests/${requestId}/confirm`, payload, options);
  }

  async request(method, path, payload, { idempotencyKey, timeoutMs, mode } = {}) {
    const headers = {
      Authorization: `Bearer ${this.apiKey}`,
      "Content-Type": "application/json",
    };
    if (idempotencyKey) headers["Idempotency-Key"] = idempotencyKey;
    if (mode) headers["X-TadaPay-Mode"] = mode;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs ?? this.timeoutMs);
    let response;
    let body;
    try {
      response = await fetch(`${this.baseUrl}${path}`, {
        method,
        headers,
        body: payload === undefined || payload === null ? undefined : JSON.stringify(payload),
        signal: controller.signal,
      });
      body = await parseJsonResponse(response);
    } finally {
      clearTimeout(timeout);
    }
    if (!response.ok) {
      throw new TadaPayAPIError({
        message: body?.error || body?.detail || `TadaPay request failed: ${response.status}`,
        status: response.status,
        error: body?.error,
        detail: body?.detail,
        body,
      });
    }
    return body;
  }
}

export function verifyWebhookSignature({
  payload,
  signatureHeader,
  secret,
  toleranceSeconds = 300,
  now = Math.floor(Date.now() / 1000),
}) {
  const parts = parseSignatureHeader(signatureHeader);
  const timestamp = Number(parts.t);
  if (!Number.isFinite(timestamp)) return false;
  if (toleranceSeconds >= 0 && Math.abs(now - timestamp) > toleranceSeconds) return false;
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(String(payload), "utf8");
  const signedPayload = Buffer.concat([Buffer.from(`${timestamp}.`, "utf8"), body]);
  const expected = crypto.createHmac("sha256", secret).update(signedPayload).digest("hex");
  const provided = parts.v1 || "";
  return timingSafeEqualHex(expected, provided);
}

export function constructWebhookEvent({ payload, signatureHeader, secret, toleranceSeconds = 300 }) {
  if (!verifyWebhookSignature({ payload, signatureHeader, secret, toleranceSeconds })) {
    throw new Error("invalid TadaPay webhook signature");
  }
  const text = Buffer.isBuffer(payload) ? payload.toString("utf8") : String(payload);
  return JSON.parse(text);
}

async function parseJsonResponse(response) {
  const text = await response.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new TadaPayAPIError({
      message: "TadaPay returned invalid JSON",
      status: response.status,
      error: "invalid_json",
      detail: error.message,
      body: text,
    });
  }
}

function withQuery(path, params = {}) {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null) query.set(key, String(value));
  }
  const suffix = query.toString();
  return suffix ? `${path}?${suffix}` : path;
}

function parseSignatureHeader(signatureHeader) {
  const values = {};
  for (const part of String(signatureHeader).split(",")) {
    const [key, value] = part.split("=");
    if (key && value) values[key] = value;
  }
  if (!values.t || !values.v1) {
    throw new Error("invalid TadaPay webhook signature header");
  }
  return values;
}

function timingSafeEqualHex(left, right) {
  const leftBuffer = Buffer.from(left, "hex");
  const rightBuffer = Buffer.from(right, "hex");
  if (leftBuffer.length !== rightBuffer.length) return false;
  return crypto.timingSafeEqual(leftBuffer, rightBuffer);
}
