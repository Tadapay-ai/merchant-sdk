export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonObject | JsonValue[];
export interface JsonObject {
  [key: string]: JsonValue | undefined;
}

export interface RequestOptions {
  idempotencyKey?: string;
  timeoutMs?: number;
  mode?: "test" | "live";
}

export type CatalogStatus = "draft" | "active" | "archived";
export type CatalogVisibility = "private" | "unlisted" | "public";
export type CatalogItemType = "digital_good" | "service" | "subscription";

export interface CatalogProductRecord extends JsonObject {
  id: string;
  merchant_id: string;
  external_product_id: string;
  name: string;
  item_type: CatalogItemType;
  status: CatalogStatus;
  visibility: CatalogVisibility;
  public_slug?: string | null;
  purchase_url?: string | null;
  mode: "test" | "live";
  version: number;
}

export interface CatalogVariantRecord extends JsonObject {
  id: string;
  product_id: string;
  external_variant_id: string;
  name: string;
  status: CatalogStatus;
  version: number;
}

export interface CatalogPriceRecord extends JsonObject {
  id: string;
  variant_id: string;
  unit_amount: number;
  currency: "USD";
  price_type: "one_time" | "recurring";
  recurring_interval?: "day" | "week" | "month" | "year" | null;
  status: CatalogStatus;
  version: number;
}

export interface CatalogProductMetrics extends JsonObject {
  checkout_count: number;
  successful_payment_count: number;
  successful_payment_amount: number;
  active_subscription_count: number;
  currency: "USD";
}

export interface CatalogProductDetail extends JsonObject {
  product: CatalogProductRecord;
  variants: CatalogVariantRecord[];
  prices: CatalogPriceRecord[];
  metrics: CatalogProductMetrics;
  publish_ready: boolean;
  publish_blockers: string[];
}

export interface CatalogProductSummary extends JsonObject {
  product: CatalogProductRecord;
  active_price?: CatalogPriceRecord | null;
  variant_count: number;
  metrics: CatalogProductMetrics;
}

export interface CatalogCheckoutResult extends JsonObject {
  checkout_snapshot_id: string;
  intent: JsonObject;
  checkout_session: JsonObject;
  hosted_url: string;
  agent_request_url: string;
}

export interface AgentCheckoutOptions extends RequestOptions {
  sessionIdempotencyKey?: string;
  checkoutSession?: JsonObject;
}

export interface TadaPayClientOptions {
  apiKey: string;
  baseUrl?: string;
  timeoutMs?: number;
}

export interface AvalancheX402Asset {
  symbol: "XSGD" | "USDC";
  address: string;
  name: string;
  version: "2";
  decimals: 6;
  network: "eip155:43114" | "eip155:43113";
}

export const AVALANCHE_X402_ASSETS: {
  readonly mainnet: Readonly<Record<"XSGD" | "USDC", AvalancheX402Asset>>;
  readonly fuji: Readonly<Record<"XSGD" | "USDC", AvalancheX402Asset>>;
};

export const X402_FACILITATORS: {
  readonly ZEROXGASLESS: {
    readonly profile: "0xgasless";
    readonly url: "https://x402.0xgasless.com";
  };
};

export interface AvalancheX402PaymentOptionInput {
  payTo: string;
  price?: string | number;
  asset?: "XSGD" | "USDC" | string;
  network?: "mainnet" | "fuji" | "eip155:43114" | "eip155:43113";
  scheme?: "exact";
  facilitatorProfile?: string;
  facilitatorUrl?: string;
  description?: string;
  mimeType?: string;
}

export interface AvalancheX402PaymentOption extends JsonObject {
  rail: "x402";
  scheme: "exact";
  network: "eip155:43114" | "eip155:43113";
  asset: string;
  pay_to: string;
  decimals: 6;
  facilitator_profile: string;
  extra: { name: string; version: "2" };
  price?: string;
  facilitator_url?: string;
  description?: string;
  mime_type?: string;
}

export function createAvalancheX402PaymentOption(
  input: AvalancheX402PaymentOptionInput,
): AvalancheX402PaymentOption;

export interface AgentCheckoutResult {
  intent: JsonObject;
  checkoutSession: JsonObject;
  hostedUrl: string;
}

export interface WebhookSignatureOptions {
  payload: string | Uint8Array;
  signatureHeader: string;
  secret: string;
  toleranceSeconds?: number;
  now?: number;
}

export interface ConstructWebhookEventOptions
  extends Omit<WebhookSignatureOptions, "now"> {}

export class TadaPayAPIError extends Error {
  status?: number;
  error?: string;
  detail?: string;
  body?: unknown;
  constructor(options: {
    message: string;
    status?: number;
    error?: string;
    detail?: string;
    body?: unknown;
  });
}

export class TadaPayClient {
  apiKey: string;
  baseUrl: string;
  timeoutMs: number;
  constructor(options: TadaPayClientOptions);

  createAgentPaymentIntent(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  getAgentPaymentIntent(intentId: string): Promise<JsonObject>;
  listAgentPaymentIntents(params?: JsonObject): Promise<JsonObject[]>;
  cancelAgentPaymentIntent(intentId: string): Promise<JsonObject>;
  getAgentPaymentIntentTimeline(intentId: string): Promise<JsonObject>;

  createCheckoutSession(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  getCheckoutSession(sessionId: string): Promise<JsonObject>;
  expireCheckoutSession(sessionId: string): Promise<JsonObject>;
  getHostedCheckoutSessionStatus(sessionId: string): Promise<JsonObject>;
  createAgentCheckout(
    intentPayload: JsonObject,
    options?: AgentCheckoutOptions,
  ): Promise<AgentCheckoutResult>;

  listReceipts(params?: JsonObject): Promise<JsonObject[]>;
  getReceipt(receiptId: string): Promise<JsonObject>;
  createRefund(payload: JsonObject, options?: RequestOptions): Promise<JsonObject>;
  listRefunds(params?: JsonObject): Promise<JsonObject[]>;
  getRefund(refundId: string): Promise<JsonObject>;

  createWebhookEndpoint(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  listWebhookEndpoints(params?: JsonObject): Promise<JsonObject[]>;
  rotateWebhookSecret(endpointId: string): Promise<JsonObject>;
  testWebhookEndpoint(endpointId: string): Promise<JsonObject>;
  listWebhookDeliveries(params?: JsonObject): Promise<JsonObject[]>;
  retryWebhookDelivery(deliveryId: string): Promise<JsonObject>;

  listRailTransactions(params?: JsonObject): Promise<JsonObject[]>;
  getRailTransaction(transactionId: string): Promise<JsonObject>;
  listEvents(params?: JsonObject): Promise<JsonObject[]>;
  getAdapterStatus(): Promise<JsonObject[]>;

  createCatalogProduct(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  createCatalogVariant(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  createCatalogPrice(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  getCatalogPrice(priceId: string): Promise<JsonObject>;
  upsertCatalogProduct(
    externalProductId: string,
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<CatalogProductDetail>;
  listCatalogProducts(
    params?: JsonObject,
    options?: RequestOptions,
  ): Promise<CatalogProductSummary[]>;
  getCatalogProduct(
    productId: string,
    options?: RequestOptions,
  ): Promise<CatalogProductDetail>;
  updateCatalogProduct(
    productId: string,
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<CatalogProductDetail>;
  activateCatalogProduct(
    productId: string,
    expectedVersion: number,
    options?: RequestOptions,
  ): Promise<CatalogProductDetail>;
  publishCatalogProduct(
    productId: string,
    expectedVersion: number,
    visibility: "unlisted" | "public",
    options?: RequestOptions,
  ): Promise<CatalogProductDetail>;
  unpublishCatalogProduct(
    productId: string,
    expectedVersion: number,
    options?: RequestOptions,
  ): Promise<CatalogProductDetail>;
  archiveCatalogProduct(
    productId: string,
    expectedVersion: number,
    options?: RequestOptions,
  ): Promise<CatalogProductDetail>;
  replaceCatalogPrice(
    priceId: string,
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<CatalogPriceRecord>;
  createCatalogCheckout(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<CatalogCheckoutResult>;
  listMarketplaceProducts(
    params?: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject[]>;
  getMarketplaceProduct(
    merchantId: string,
    productSlug: string,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  createMarketplaceCheckout(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<CatalogCheckoutResult>;

  createPayer(payload: JsonObject, options?: RequestOptions): Promise<JsonObject>;
  getPayer(payerId: string): Promise<JsonObject>;
  listPayers(params?: JsonObject): Promise<JsonObject[]>;
  createSubscription(
    payload: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  getSubscription(subscriptionId: string): Promise<JsonObject>;
  listSubscriptions(): Promise<JsonObject[]>;
  cancelSubscription(
    subscriptionId: string,
    options?: RequestOptions & { mode?: "at_period_end" | "immediate" },
  ): Promise<JsonObject>;
  reauthorizeSubscription(
    subscriptionId: string,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  listInvoices(): Promise<JsonObject[]>;
  getInvoice(invoiceId: string): Promise<JsonObject>;
  retryInvoice(invoiceId: string, options?: RequestOptions): Promise<JsonObject>;
  getPaymentMandate(mandateId: string): Promise<JsonObject>;

  confirmAgentPaymentRequest(
    requestId: string,
    payload?: JsonObject,
    options?: RequestOptions,
  ): Promise<JsonObject>;
  request(
    method: string,
    path: string,
    payload?: JsonObject | null,
    options?: RequestOptions,
  ): Promise<unknown>;
}

export function verifyWebhookSignature(options: WebhookSignatureOptions): boolean;
export function constructWebhookEvent(
  options: ConstructWebhookEventOptions,
): JsonObject;
