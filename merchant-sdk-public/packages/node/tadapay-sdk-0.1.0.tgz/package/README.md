# `@tadapay/sdk`

Official server-side Node.js SDK for TadaPay merchant checkout.

## Install

Version `0.1.0` is not yet published on npm. From the extracted merchant SDK
bundle, run:

```sh
npm install ./packages/node/tadapay-sdk-0.1.0.tgz
```

The registry command below applies after public publication.

```sh
npm install @tadapay/sdk
```

Node.js 18 or newer is required.

## Create an agent checkout

```js
import { TadaPayClient } from "@tadapay/sdk";

const tadapay = new TadaPayClient({
  apiKey: process.env.TADAPAY_API_KEY,
  baseUrl: process.env.TADAPAY_BASE_URL,
});

const checkout = await tadapay.createAgentCheckout(
  {
    merchant_order: { id: "order_123" },
    commerce_type: "digital_service",
    amount: {
      currency: "USD",
      subtotal: 2900,
      tax: 0,
      shipping: 0,
      discount: 0,
      total: 2900,
    },
    line_items: [
      {
        id: "credits",
        name: "1,000 API credits",
        quantity: 1,
        unit_amount: 2900,
        currency: "USD",
        item_type: "digital_good",
      },
    ],
    fulfillment: {
      type: "api_credits",
      delivery_mode: "instant",
    },
    payment_options: [{ rail: "sandbox", mode: "test" }],
  },
  {
    idempotencyKey: "order_123:intent:v1",
    sessionIdempotencyKey: "order_123:session:v1",
  },
);

console.log(checkout.hostedUrl);
```

API keys must only be used on the merchant server. Send `hostedUrl` to the
browser; never expose the TadaPay API key in frontend code.

## Verify a webhook

The verifier must receive the unmodified request body:

```js
import { constructWebhookEvent } from "@tadapay/sdk";

const event = constructWebhookEvent({
  payload: rawRequestBody,
  signatureHeader: request.headers["tadapay-signature"],
  secret: process.env.TADAPAY_WEBHOOK_SECRET,
});
```

See the
[merchant SDK Quickstart](https://github.com/jinchengjc/Payment/blob/main/tadapay/docs/merchant_sdk_quickstart.md)
for the complete server and browser flow.
