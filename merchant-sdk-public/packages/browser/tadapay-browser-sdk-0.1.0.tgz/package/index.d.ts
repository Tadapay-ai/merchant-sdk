export interface OpenHostedCheckoutOptions {
  target?: string;
}

export type CheckoutStatus =
  | "open"
  | "expired"
  | "canceled"
  | "failed"
  | "succeeded"
  | "completed"
  | string;

export interface PayWithAgentClickContext {
  event: Event;
  hostedUrl: string;
  button: HTMLButtonElement;
}

export interface MountPayWithAgentButtonOptions {
  element: string | Element;
  hostedUrl: string;
  label?: string;
  loadingLabel?: string;
  unavailableLabel?: string;
  expiredLabel?: string;
  className?: string;
  disabled?: boolean;
  status?: CheckoutStatus;
  target?: string;
  onClick?: (
    context: PayWithAgentClickContext,
  ) => void | boolean | Promise<void>;
}

export interface UpdatePayWithAgentButtonOptions {
  disabled?: boolean;
  status?: CheckoutStatus;
  label?: string;
  unavailableLabel?: string;
  expiredLabel?: string;
}

export function openHostedCheckout(
  hostedUrl: string,
  options?: OpenHostedCheckoutOptions,
): void;
export function openSubscriptionAuthorization(
  authorizationUrl: string,
  options?: OpenHostedCheckoutOptions,
): void;
export function mountPayWithAgentButton(
  options: MountPayWithAgentButtonOptions,
): HTMLButtonElement;
export function updatePayWithAgentButton(
  button: HTMLButtonElement,
  options?: UpdatePayWithAgentButtonOptions,
): HTMLButtonElement;
