# `@tadapay/browser-sdk`

Browser helpers for opening a TadaPay hosted checkout and rendering a
CSS-free `Pay with Agent` button.

## Install

Version `0.1.0` is not yet published on npm. From the extracted merchant SDK
bundle, run:

```sh
npm install ./packages/browser/tadapay-browser-sdk-0.1.0.tgz
```

For a no-build page, use the bundle's local `html/tadapay-browser-sdk.js`.
The registry/CDN examples below apply after public publication.

```sh
npm install @tadapay/browser-sdk
```

```js
import { mountPayWithAgentButton } from "@tadapay/browser-sdk";

mountPayWithAgentButton({
  element: "#agent-checkout",
  hostedUrl: checkoutSession.hosted_url,
  status: checkoutSession.status,
});
```

The `hostedUrl` must come from your merchant server. Do not create payment
intents from browser code and do not expose a TadaPay API key in the browser.

For a no-build integration, pin an exact SDK version:

```html
<script type="module">
  import { mountPayWithAgentButton } from
    "https://cdn.jsdelivr.net/npm/@tadapay/browser-sdk@0.1.0/+esm";
</script>
```

See the
[merchant SDK Quickstart](https://github.com/jinchengjc/Payment/blob/main/tadapay/docs/merchant_sdk_quickstart.md)
for the complete flow.
