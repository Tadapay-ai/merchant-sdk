from __future__ import annotations

import re
from typing import Any


AVALANCHE_X402_ASSETS: dict[str, dict[str, dict[str, Any]]] = {
    "mainnet": {
        "XSGD": {
            "symbol": "XSGD",
            "address": "0xb2F85b7AB3c2b6f62DF06dE6aE7D09c010a5096E",
            "name": "XSGD",
            "version": "2",
            "decimals": 6,
            "network": "eip155:43114",
        },
        "USDC": {
            "symbol": "USDC",
            "address": "0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E",
            "name": "USD Coin",
            "version": "2",
            "decimals": 6,
            "network": "eip155:43114",
        },
    },
    "fuji": {
        "XSGD": {
            "symbol": "XSGD",
            "address": "0xd769410dc8772695a7f55a304d2125320a65c2a5",
            "name": "XSGD",
            "version": "2",
            "decimals": 6,
            "network": "eip155:43113",
        },
        "USDC": {
            "symbol": "USDC",
            "address": "0x5425890298aed601595a70AB815c96711a31Bc65",
            "name": "USD Coin",
            "version": "2",
            "decimals": 6,
            "network": "eip155:43113",
        },
    },
}

X402_FACILITATORS = {
    "0xgasless": {
        "profile": "0xgasless",
        "url": "https://x402.0xgasless.com",
    }
}


def build_avalanche_x402_payment_option(
    *,
    pay_to: str,
    price: str | int | float | None = None,
    asset: str = "XSGD",
    network: str = "mainnet",
    scheme: str = "exact",
    facilitator_profile: str = "0xgasless",
    facilitator_url: str | None = None,
    description: str | None = None,
    mime_type: str | None = None,
) -> dict[str, Any]:
    if not re.fullmatch(r"0x[a-fA-F0-9]{40}", str(pay_to or "")):
        raise ValueError("pay_to must be a valid EVM merchant wallet address")
    network_key = {
        "eip155:43114": "mainnet",
        "eip155:43113": "fuji",
    }.get(network, network)
    assets = AVALANCHE_X402_ASSETS.get(network_key)
    if assets is None:
        raise ValueError("network must be mainnet, fuji, eip155:43114, or eip155:43113")
    asset_key = str(asset).upper()
    asset_config = assets.get(asset_key)
    if asset_config is None:
        asset_config = next(
            (
                candidate
                for candidate in assets.values()
                if candidate["address"].lower() == str(asset).lower()
            ),
            None,
        )
    if asset_config is None:
        raise ValueError(f"unsupported Avalanche asset: {asset}")
    if scheme != "exact":
        raise ValueError("Avalanche x402 options currently support only exact scheme")

    option: dict[str, Any] = {
        "rail": "x402",
        "scheme": scheme,
        "network": asset_config["network"],
        "asset": asset_config["address"],
        "pay_to": str(pay_to),
        "decimals": asset_config["decimals"],
        "facilitator_profile": facilitator_profile,
        "extra": {
            "name": asset_config["name"],
            "version": asset_config["version"],
        },
    }
    if price is not None:
        option["price"] = str(price)
    if facilitator_url:
        option["facilitator_url"] = str(facilitator_url)
    if description:
        option["description"] = str(description)
    if mime_type:
        option["mime_type"] = str(mime_type)
    return option
