from __future__ import annotations

import hashlib
import hmac
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any


class TadaPayAPIError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        error: str | None = None,
        detail: str | None = None,
        details: dict[str, Any] | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.error = error
        self.detail = detail
        self.details = details
        self.body = body


class TadaPayClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "http://127.0.0.1:8080",
        timeout_seconds: float = 30.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds

    def create_agent_payment_intent(
        self,
        payload: dict[str, Any],
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/agent_payment_intents", payload, idempotency_key)

    def get_agent_payment_intent(self, intent_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/agent_payment_intents/{intent_id}")

    def list_agent_payment_intents(self, **params: Any) -> list[dict[str, Any]]:
        return self._request("GET", _with_query("/v1/agent_payment_intents", params))

    def cancel_agent_payment_intent(self, intent_id: str) -> dict[str, Any]:
        return self._request("POST", f"/v1/agent_payment_intents/{intent_id}/cancel")

    def get_agent_payment_intent_timeline(self, intent_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/agent_payment_intents/{intent_id}/timeline")

    def create_checkout_session(
        self,
        payload: dict[str, Any],
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/checkout_sessions", payload, idempotency_key)

    def get_checkout_session(self, session_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/checkout_sessions/{session_id}")

    def expire_checkout_session(self, session_id: str) -> dict[str, Any]:
        return self._request("POST", f"/v1/checkout_sessions/{session_id}/expire")

    def get_hosted_checkout_session_status(self, session_id: str) -> dict[str, Any]:
        return self._request("GET", f"/checkout/sessions/{session_id}/status")

    def create_agent_checkout(
        self,
        intent_payload: dict[str, Any],
        *,
        idempotency_key: str | None = None,
        session_idempotency_key: str | None = None,
        checkout_session: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        intent = self.create_agent_payment_intent(intent_payload, idempotency_key)
        session_payload = {"intent_id": intent["id"], **(checkout_session or {})}
        session = self.create_checkout_session(session_payload, session_idempotency_key)
        return {"intent": intent, "checkout_session": session, "hosted_url": session["hosted_url"]}

    def list_receipts(self, **params: Any) -> list[dict[str, Any]]:
        return self._request("GET", _with_query("/v1/receipts", params))

    def get_receipt(self, receipt_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/receipts/{receipt_id}")

    def create_refund(
        self,
        payload: dict[str, Any],
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/refunds", payload, idempotency_key)

    def list_refunds(self, **params: Any) -> list[dict[str, Any]]:
        return self._request("GET", _with_query("/v1/refunds", params))

    def get_refund(self, refund_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/refunds/{refund_id}")

    def create_webhook_endpoint(
        self,
        payload: dict[str, Any],
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/webhook_endpoints", payload, idempotency_key)

    def list_webhook_endpoints(self, **params: Any) -> list[dict[str, Any]]:
        return self._request("GET", _with_query("/v1/webhook_endpoints", params))

    def rotate_webhook_secret(self, endpoint_id: str) -> dict[str, Any]:
        return self._request("POST", f"/v1/webhook_endpoints/{endpoint_id}/rotate_secret")

    def test_webhook_endpoint(self, endpoint_id: str) -> dict[str, Any]:
        return self._request("POST", f"/v1/webhook_endpoints/{endpoint_id}/test")

    def list_webhook_deliveries(self, **params: Any) -> list[dict[str, Any]]:
        return self._request("GET", _with_query("/v1/webhook_deliveries", params))

    def retry_webhook_delivery(self, delivery_id: str) -> dict[str, Any]:
        return self._request("POST", f"/v1/webhook_deliveries/{delivery_id}/retry")

    def list_rail_transactions(self, **params: Any) -> list[dict[str, Any]]:
        return self._request("GET", _with_query("/v1/rail_transactions", params))

    def get_rail_transaction(self, transaction_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/rail_transactions/{transaction_id}")

    def list_events(self, **params: Any) -> list[dict[str, Any]]:
        return self._request("GET", _with_query("/v1/events", params))

    def get_adapter_status(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/adapter_status")

    def create_catalog_product(
        self,
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/catalog/products", payload, idempotency_key)

    def create_catalog_variant(
        self,
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/catalog/variants", payload, idempotency_key)

    def create_catalog_price(
        self,
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/catalog/prices", payload, idempotency_key)

    def get_catalog_price(self, price_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/catalog/prices/{price_id}")

    def upsert_catalog_product(
        self,
        external_product_id: str,
        payload: dict[str, Any],
        idempotency_key: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._request(
            "PUT",
            f"/v1/catalog/products/{urllib.parse.quote(external_product_id, safe='')}",
            payload,
            idempotency_key,
            mode,
        )

    def list_catalog_products(
        self,
        *,
        mode: str = "test",
        **params: Any,
    ) -> list[dict[str, Any]]:
        return self._request(
            "GET",
            _with_query("/v1/catalog/products", params),
            mode=mode,
        )

    def get_catalog_product(
        self,
        product_id: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._request("GET", f"/v1/catalog/products/{product_id}", mode=mode)

    def update_catalog_product(
        self,
        product_id: str,
        payload: dict[str, Any],
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._request(
            "PATCH",
            f"/v1/catalog/products/{product_id}",
            payload,
            mode=mode,
        )

    def activate_catalog_product(
        self,
        product_id: str,
        expected_version: int,
        idempotency_key: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._catalog_product_action(
            product_id,
            "activate",
            {"expected_version": expected_version},
            idempotency_key,
            mode,
        )

    def publish_catalog_product(
        self,
        product_id: str,
        expected_version: int,
        visibility: str,
        idempotency_key: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._catalog_product_action(
            product_id,
            "publish",
            {"expected_version": expected_version, "visibility": visibility},
            idempotency_key,
            mode,
        )

    def unpublish_catalog_product(
        self,
        product_id: str,
        expected_version: int,
        idempotency_key: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._catalog_product_action(
            product_id,
            "unpublish",
            {"expected_version": expected_version},
            idempotency_key,
            mode,
        )

    def archive_catalog_product(
        self,
        product_id: str,
        expected_version: int,
        idempotency_key: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._catalog_product_action(
            product_id,
            "archive",
            {"expected_version": expected_version},
            idempotency_key,
            mode,
        )

    def replace_catalog_price(
        self,
        price_id: str,
        payload: dict[str, Any],
        idempotency_key: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/v1/catalog/prices/{price_id}/replace",
            payload,
            idempotency_key,
            mode,
        )

    def create_catalog_checkout(
        self,
        payload: dict[str, Any],
        idempotency_key: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/v1/catalog/checkouts",
            payload,
            idempotency_key,
            mode,
        )

    def list_marketplace_products(
        self,
        *,
        mode: str | None = None,
        **params: Any,
    ) -> list[dict[str, Any]]:
        """Discover active public products across all merchants."""

        return self._request(
            "GET",
            _with_query("/agent/marketplace/products", params),
            mode=mode,
        )

    def get_marketplace_product(
        self,
        merchant_id: str,
        product_slug: str,
        *,
        mode: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "GET",
            f"/agent/marketplace/products/{urllib.parse.quote(merchant_id, safe='')}/"
            f"{urllib.parse.quote(product_slug, safe='')}",
            mode=mode,
        )

    def create_marketplace_checkout(
        self,
        payload: dict[str, Any],
        idempotency_key: str,
        *,
        mode: str = "test",
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/agent/marketplace/checkouts",
            payload,
            idempotency_key,
            mode,
        )

    def _catalog_product_action(
        self,
        product_id: str,
        action: str,
        payload: dict[str, Any],
        idempotency_key: str,
        mode: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/v1/catalog/products/{product_id}/{action}",
            payload,
            idempotency_key,
            mode,
        )

    def create_payer(
        self,
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/payers", payload, idempotency_key)

    def get_payer(self, payer_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/payers/{payer_id}")

    def list_payers(self, **params: Any) -> list[dict[str, Any]]:
        return self._request("GET", _with_query("/v1/payers", params))

    def create_subscription(
        self,
        payload: dict[str, Any],
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._request("POST", "/v1/subscriptions", payload, idempotency_key)

    def get_subscription(self, subscription_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/subscriptions/{subscription_id}")

    def list_subscriptions(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/subscriptions")

    def cancel_subscription(
        self,
        subscription_id: str,
        *,
        mode: str = "at_period_end",
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/v1/subscriptions/{subscription_id}/cancel",
            {"mode": mode},
            idempotency_key,
        )

    def reauthorize_subscription(
        self,
        subscription_id: str,
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/v1/subscriptions/{subscription_id}/reauthorize",
            {},
            idempotency_key,
        )

    def list_invoices(self) -> list[dict[str, Any]]:
        return self._request("GET", "/v1/invoices")

    def get_invoice(self, invoice_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/invoices/{invoice_id}")

    def retry_invoice(
        self,
        invoice_id: str,
        idempotency_key: str,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/v1/invoices/{invoice_id}/retry",
            {},
            idempotency_key,
        )

    def get_payment_mandate(self, mandate_id: str) -> dict[str, Any]:
        return self._request("GET", f"/v1/payment_mandates/{mandate_id}")

    def confirm_agent_payment_request(
        self,
        request_id: str,
        payload: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/agent/payment_requests/{request_id}/confirm",
            payload or {},
            idempotency_key,
        )

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
        mode: str | None = None,
    ) -> Any:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        if mode:
            headers["X-TadaPay-Mode"] = mode
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=data,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                return _loads_response(response.read().decode("utf-8"), response.status)
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            body = _loads_response(raw, exc.code, raise_invalid_json=False)
            if isinstance(body, dict):
                message = body.get("error") or body.get("detail") or f"TadaPay request failed: {exc.code}"
                raise TadaPayAPIError(
                    message,
                    status=exc.code,
                    error=body.get("error"),
                    detail=body.get("detail"),
                    details=body.get("details"),
                    body=body,
                ) from exc
            raise TadaPayAPIError(
                f"TadaPay request failed: {exc.code}",
                status=exc.code,
                body=raw,
            ) from exc


def verify_webhook_signature(
    payload: bytes | str,
    signature_header: str,
    secret: str,
    tolerance_seconds: int = 300,
    now: int | None = None,
) -> bool:
    payload_bytes = payload.encode("utf-8") if isinstance(payload, str) else payload
    parts = _parse_signature_header(signature_header)
    timestamp = int(parts["t"])
    current = int(time.time()) if now is None else now
    if tolerance_seconds >= 0 and abs(current - timestamp) > tolerance_seconds:
        return False
    signed_payload = f"{timestamp}.".encode("utf-8") + payload_bytes
    expected = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, parts.get("v1", ""))


def construct_webhook_event(
    payload: bytes | str,
    signature_header: str,
    secret: str,
    tolerance_seconds: int = 300,
) -> dict[str, Any]:
    if not verify_webhook_signature(payload, signature_header, secret, tolerance_seconds):
        raise ValueError("invalid TadaPay webhook signature")
    payload_text = payload.decode("utf-8") if isinstance(payload, bytes) else payload
    return json.loads(payload_text)


def _parse_signature_header(signature_header: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for part in signature_header.split(","):
        key, _, value = part.partition("=")
        if key and value:
            values[key] = value
    if "t" not in values or "v1" not in values:
        raise ValueError("invalid TadaPay webhook signature header")
    return values


def _loads_response(text: str, status: int, raise_invalid_json: bool = True) -> Any:
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        if raise_invalid_json:
            raise TadaPayAPIError(
                "TadaPay returned invalid JSON",
                status=status,
                error="invalid_json",
                detail=str(exc),
                body=text,
            ) from exc
        return text


def _with_query(path: str, params: dict[str, Any]) -> str:
    clean = {key: value for key, value in params.items() if value is not None}
    query = urllib.parse.urlencode(clean)
    return f"{path}?{query}" if query else path
